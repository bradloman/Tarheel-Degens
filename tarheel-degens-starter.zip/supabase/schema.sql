-- Tarheel Degens starter schema.
-- Apply in Supabase SQL Editor. Review/tighten RLS policies before production.

create extension if not exists pgcrypto;

create type public.match_status as enum ('planned', 'live', 'completed');
create type public.wager_status as enum ('active', 'pending_press', 'won', 'lost', 'push');
create type public.game_type as enum ('nassau', 'skins', 'quota', 'mega_nassau', 'hammer', 'custom');

create table public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Tarheel Degens',
  created_at timestamptz not null default now()
);

create table public.club_members (
  club_id uuid not null references public.clubs(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  handicap_index numeric(4,1) not null,
  role text not null default 'player' check (role in ('owner','player')),
  primary key (club_id, user_id)
);

create table public.club_settings (
  club_id uuid primary key references public.clubs(id) on delete cascade,
  fixed_bet_amount numeric(10,2) not null default 10 check (fixed_bet_amount > 0),
  press_requires_confirmation boolean not null default true,
  press_starts_next_hole boolean not null default true,
  max_press_depth integer, -- null means no configured cap
  created_at timestamptz not null default now()
);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  name text not null,
  tees text not null,
  course_rating numeric(4,1) not null,
  slope_rating integer not null check (slope_rating between 55 and 155),
  par integer not null check (par between 54 and 80),
  hole_data jsonb not null, -- 9/18 holes: {hole, par, stroke_index}
  created_at timestamptz not null default now()
);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  course_id uuid references public.courses(id),
  played_on date not null default current_date,
  status public.match_status not null default 'planned',
  format_label text not null default 'Nassau',
  round_count integer not null default 1,
  total_holes integer not null default 18 check (total_holes >= 1),
  fixed_bet_amount numeric(10,2) not null check (fixed_bet_amount > 0),
  notes text,
  created_by uuid not null references auth.users(id),
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.match_players (
  match_id uuid not null references public.matches(id) on delete cascade,
  user_id uuid not null references auth.users(id),
  handicap_index_at_play numeric(4,1) not null,
  course_handicap integer,
  playing_handicap integer,
  tee_name text,
  primary key (match_id, user_id)
);

create table public.hole_scores (
  match_id uuid not null references public.matches(id) on delete cascade,
  hole_number integer not null check (hole_number > 0),
  user_id uuid not null references auth.users(id),
  gross_score integer check (gross_score between 1 and 20),
  net_score integer,
  par integer not null check (par between 3 and 6),
  stroke_index integer check (stroke_index between 1 and 18),
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now(),
  primary key (match_id, hole_number, user_id)
);

-- Every independently scored contest is a segment. Mega Nassau can contain many segments
-- (front/back/overall and custom 9/18/36+ hole windows) within one parent match.
create table public.match_segments (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  parent_segment_id uuid references public.match_segments(id) on delete cascade,
  label text not null,
  game_type public.game_type not null,
  start_hole integer not null,
  end_hole integer not null,
  fixed_bet_amount numeric(10,2) not null,
  status public.match_status not null default 'planned',
  player1_holes_up integer not null default 0,
  player2_holes_up integer not null default 0,
  winner_user_id uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (end_hole >= start_hole)
);

-- Wagers can be presses of other wagers, allowing press-of-press chains.
create table public.wagers (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  segment_id uuid references public.match_segments(id) on delete cascade,
  parent_wager_id uuid references public.wagers(id) on delete cascade,
  game_type public.game_type not null,
  label text not null,
  fixed_bet_amount numeric(10,2) not null check (fixed_bet_amount > 0),
  status public.wager_status not null default 'active',
  press_trigger_hole integer,
  press_start_hole integer,
  down_player_id uuid references auth.users(id),
  winner_user_id uuid references auth.users(id),
  gross_payout numeric(10,2),
  net_payout numeric(10,2),
  settled_at timestamptz,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (press_start_hole is null or press_trigger_hole is null or press_start_hole > press_trigger_hole)
);

create table public.wager_events (
  id uuid primary key default gen_random_uuid(),
  wager_id uuid not null references public.wagers(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  event_type text not null check (event_type in ('press_opportunity','press_accepted','press_declined','hammer_called','hammer_accepted','hammer_declined','wager_settled','note')),
  hole_number integer,
  event_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.settlements (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  payer_user_id uuid not null references auth.users(id),
  payee_user_id uuid not null references auth.users(id),
  amount numeric(10,2) not null check (amount >= 0),
  note text,
  settled_at timestamptz not null default now()
);

create index matches_club_date_idx on public.matches(club_id, played_on desc);
create index matches_status_idx on public.matches(status);
create index wagers_match_status_idx on public.wagers(match_id, status);
create index segments_match_idx on public.match_segments(match_id);
create index scores_match_hole_idx on public.hole_scores(match_id, hole_number);

-- Security note:
-- Do not enable client writes until membership-based RLS policies are installed.
-- Production setup must enforce club membership for SELECT/INSERT/UPDATE/DELETE and
-- use server-side RPC transactions for score-save + press detection + wager creation.


-- Hammer per-hole state. Keep each hole's amount and holder independent.
create type public.hammer_status as enum ('not_thrown','held_by_player1','held_by_player2','hole_complete');

create table public.hammer_holes (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references public.matches(id) on delete cascade,
  hole_number integer not null check (hole_number > 0),
  base_amount numeric(10,2) not null check (base_amount > 0),
  current_amount numeric(12,2) not null check (current_amount >= base_amount),
  status public.hammer_status not null default 'not_thrown',
  holder_user_id uuid references auth.users(id),
  throw_count integer not null default 0 check (throw_count >= 0),
  declined_by_user_id uuid references auth.users(id),
  result text check (result in ('player1_wins','player2_wins','push')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (match_id, hole_number)
);

-- Append-only audit trail makes every throw/accept/decline and amount change reviewable.
create table public.hammer_events (
  id uuid primary key default gen_random_uuid(),
  hammer_hole_id uuid not null references public.hammer_holes(id) on delete cascade,
  actor_user_id uuid references auth.users(id),
  event_type text not null check (event_type in ('hammer_thrown','hammer_rethrown','hammer_accepted','hammer_declined','hammer_hole_completed')),
  amount_before numeric(12,2) not null,
  amount_after numeric(12,2) not null,
  event_data jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
