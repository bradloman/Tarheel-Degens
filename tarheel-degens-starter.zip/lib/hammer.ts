import type { Wager } from "./types";

export type HammerStatus = "not_thrown" | "held_by_player1" | "held_by_player2" | "hole_complete";

export interface HammerHoleState {
  hole: number;
  baseAmount: number;
  currentAmount: number;
  status: HammerStatus;
  holderPlayerId: string | null;
  throwCount: number;
  declinedByPlayerId?: string;
  result?: "player1_wins" | "player2_wins" | "push";
}

export type HammerAction =
  | { type: "throw"; playerId: string }
  | { type: "accept"; playerId: string }
  | { type: "decline"; playerId: string }
  | { type: "complete"; result: "player1_wins" | "player2_wins" | "push" };

export interface HammerTransition {
  state: HammerHoleState;
  event: { type: string; actorPlayerId?: string; amountBefore: number; amountAfter: number; note: string };
}

/**
 * Hammer house rules captured from Tarheel Degens:
 * - A fixed base amount starts each hole.
 * - Either player may throw the first hammer only at the beginning of the match.
 * - Once the first hammer is thrown, the holder is the only player who may throw again.
 * - The opponent can accept (doubling the current hole amount and transferring the hammer)
 *   or decline (losing the current amount); decline ends the hole's Hammer wager.
 * - Accepted hammers can repeat without a configured limit.
 * - A declined hammer does not transfer the hammer; it remains with the thrower.
 *
 * The caller must gate `throw` so the first throw is only available at match start.
 */
export function applyHammerAction(
  state: HammerHoleState,
  action: HammerAction,
  players: [string, string],
  isBeginningOfMatch: boolean
): HammerTransition {
  const before = state.currentAmount;
  const [p1, p2] = players;
  const other = (id: string) => id === p1 ? p2 : p1;

  if (state.status === "hole_complete") throw new Error("This hole's Hammer wager is already complete.");

  if (action.type === "throw") {
    if (state.status === "not_thrown") {
      if (!isBeginningOfMatch) throw new Error("The first Hammer may only be thrown at the beginning of the match.");
      if (action.playerId !== p1 && action.playerId !== p2) throw new Error("Unknown player.");
      return {
        state: { ...state, status: action.playerId === p1 ? "held_by_player1" : "held_by_player2", holderPlayerId: action.playerId, throwCount: state.throwCount + 1 },
        event: { type: "hammer_thrown", actorPlayerId: action.playerId, amountBefore: before, amountAfter: before, note: "First Hammer thrown; opponent must accept or decline." }
      };
    }
    if (action.playerId !== state.holderPlayerId) throw new Error("Only the current Hammer holder may throw it again.");
    return {
      state: { ...state, throwCount: state.throwCount + 1 },
      event: { type: "hammer_rethrown", actorPlayerId: action.playerId, amountBefore: before, amountAfter: before, note: "Hammer thrown again; opponent must accept or decline." }
    };
  }

  if (state.status === "not_thrown") throw new Error("A Hammer must be thrown before it can be accepted or declined.");
  if (action.type === "accept") {
    if (action.playerId !== other(state.holderPlayerId!)) throw new Error("Only the opponent may accept the Hammer.");
    const nextHolder = action.playerId;
    return {
      state: { ...state, currentAmount: before * 2, status: nextHolder === p1 ? "held_by_player1" : "held_by_player2", holderPlayerId: nextHolder },
      event: { type: "hammer_accepted", actorPlayerId: action.playerId, amountBefore: before, amountAfter: before * 2, note: "Accepted; hole amount doubled and Hammer transfers to accepter." }
    };
  }
  if (action.type === "decline") {
    if (action.playerId !== other(state.holderPlayerId!)) throw new Error("Only the opponent may decline the Hammer.");
    return {
      state: { ...state, status: "hole_complete", declinedByPlayerId: action.playerId },
      event: { type: "hammer_declined", actorPlayerId: action.playerId, amountBefore: before, amountAfter: before, note: `Decliner loses the current $${before} Hammer amount; holder retains the Hammer.` }
    };
  }
  return {
    state: { ...state, status: "hole_complete", result: action.result },
    event: { type: "hammer_hole_completed", amountBefore: before, amountAfter: before, note: `Hole Hammer result: ${action.result}.` }
  };
}

export function newHammerHole(hole: number, baseAmount: number): HammerHoleState {
  return { hole, baseAmount, currentAmount: baseAmount, status: "not_thrown", holderPlayerId: null, throwCount: 0 };
}
