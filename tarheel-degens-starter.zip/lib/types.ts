export type GameType = "Nassau" | "Skins" | "Quota" | "Mega Nassau" | "Hammer" | "Custom";
export type MatchStatus = "planned" | "live" | "completed";
export type BetStatus = "active" | "pending_press" | "won" | "lost" | "push";

export interface Player {
  id: string;
  name: string;
  handicapIndex: number;
}

export interface HoleScore {
  hole: number;
  player1Gross: number | null;
  player2Gross: number | null;
  par: number;
  strokeIndex: number;
}

export interface MatchSegment {
  id: string;
  label: string;
  startHole: number;
  endHole: number;
  status: MatchStatus;
  player1HolesUp: number;
  pressParentId?: string;
  pressStartHole?: number;
}

export interface Wager {
  id: string;
  gameType: GameType;
  label: string;
  amount: number;
  status: BetStatus;
  winnerPlayerId?: string;
  pressParentId?: string;
  pressStartHole?: number;
  playerDownTwoId?: string;
}

export interface GolfMatch {
  id: string;
  date: string;
  course: string;
  year: number;
  status: MatchStatus;
  players: [Player, Player];
  gameTypes: GameType[];
  fixedBetAmount: number;
  currentHole: number;
  scores: HoleScore[];
  segments: MatchSegment[];
  wagers: Wager[];
}
