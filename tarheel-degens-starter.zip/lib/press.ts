import type { Wager } from "./types";

/**
 * Call when the score on a hole is saved.
 * The calling code should supply each wager's match status independently.
 * A press is only offered when the eligible wager is two down and no unresolved
 * press decision exists for that wager. The press begins on the NEXT hole.
 */
export function getPressOpportunities(
  wagers: Wager[],
  downByPlayerId: Record<string, number>,
  currentHole: number
) {
  return wagers
    .filter(w => w.status === "active" && !w.pressParentId)
    .flatMap(w => {
      const playerDownTwoId = Object.keys(downByPlayerId).find(id => downByPlayerId[id] >= 2);
      if (!playerDownTwoId) return [];
      return [{
        wagerId: w.id,
        wagerLabel: w.label,
        amount: w.amount,
        playerDownTwoId,
        startsOnHole: currentHole + 1,
        prompt: `${playerDownTwoId} is 2+ down in ${w.label}. Start a $${w.amount} press on hole ${currentHole + 1}?`
      }];
    });
}

/** Create a child wager when the user confirms a press. Supports pressing a press. */
export function createPress(parent: Wager, newId: string, currentHole: number): Wager {
  return {
    id: newId,
    gameType: parent.gameType,
    label: `Press of ${parent.label}`,
    amount: parent.amount,
    status: "active",
    pressParentId: parent.id,
    pressStartHole: currentHole + 1
  };
}
