import type { GolfMatch, Player } from "./types";

export const you: Player = { id: "player-you", name: "You", handicapIndex: 12.6 };
export const friend: Player = { id: "player-friend", name: "Your Buddy", handicapIndex: 15.3 };

export const demoMatch: GolfMatch = {
  id: "demo-live",
  date: "2026-10-14",
  course: "Demo Club · Blue Tees",
  year: 2026,
  status: "live",
  players: [you, friend],
  gameTypes: ["Nassau", "Skins", "Mega Nassau", "Hammer"],
  fixedBetAmount: 10,
  currentHole: 7,
  scores: Array.from({ length: 18 }, (_, i) => ({
    hole: i + 1,
    player1Gross: i < 6 ? [5, 4, 5, 4, 6, 4][i] : null,
    player2Gross: i < 6 ? [6, 5, 4, 5, 5, 5][i] : null,
    par: [4, 4, 5, 3, 4, 4, 4, 3, 5, 4, 4, 3, 5, 4, 4, 3, 4, 5][i],
    strokeIndex: i + 1
  })),
  segments: [
    { id: "front", label: "Front 9", startHole: 1, endHole: 9, status: "live", player1HolesUp: 1 },
    { id: "back", label: "Back 9", startHole: 10, endHole: 18, status: "planned", player1HolesUp: 0 },
    { id: "overall", label: "Overall 18", startHole: 1, endHole: 18, status: "live", player1HolesUp: 1 }
  ],
  wagers: [
    { id: "nassau-front", gameType: "Nassau", label: "Nassau · Front 9", amount: 10, status: "active" },
    { id: "nassau-back", gameType: "Nassau", label: "Nassau · Back 9", amount: 10, status: "active" },
    { id: "nassau-overall", gameType: "Nassau", label: "Nassau · Overall", amount: 10, status: "active" },
    { id: "mega-36", gameType: "Mega Nassau", label: "Mega Nassau · 36-hole match", amount: 10, status: "active" },
    { id: "hammer-1", gameType: "Hammer", label: "Hammer · Hole 7", amount: 10, status: "active" }
  ]
};
