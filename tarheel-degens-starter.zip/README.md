# Tarheel Degens — starter web app

A mobile-first starter for tracking net golf matches, Nassau, skins, Quota, Mega Nassau, Hammer, presses, settlements, and season history.

## Included
- Next.js App Router + TypeScript + Tailwind starter
- Responsive dashboard and live-match scorecard UI
- Shared match model and SQL schema for Supabase
- Press workflow: detect a two-down state, show a confirmation prompt, and start the press on the **next hole**
- Mega Nassau model: multiple nested match segments (9/18/36+ holes), with presses on individual matches and presses of presses
- One default fixed wager amount, configurable for the club
- Year/game/date/result filters in the history page
- Deployment checklist

## Important status
This is a deployable **starter**, not a fully production-ready betting ledger. The UI demo uses browser-local sample data until Supabase credentials and authenticated shared data access are configured. Do not use local demo data as a shared or authoritative record. Before real use, implement and test the transaction/settlement functions and handicap calculations against your exact house rules.

## Requirements
- Node.js 20+
- Supabase project
- Vercel account (or another Next.js host)

## Run locally
```bash
npm install
cp .env.example .env.local
# Fill in Supabase values after creating the project
npm run dev
```

## Publish
1. Create a Supabase project.
2. In Supabase SQL Editor, run `supabase/schema.sql`.
3. Add your two player profiles and configure the initial fixed bet amount in the `club_settings` table.
4. Configure Supabase Auth. Invite both players by email; the starter's schema supports a club membership table.
5. Create a Vercel project and import this repository.
6. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel project environment variables.
7. Deploy, then connect a domain you own in Vercel. Check availability of a domain such as `tarheeldegens.com` before buying it.
8. Before using for real money accounting, implement row-level security policies and server-side RPCs for score updates, press creation, and settlement. Never expose the Supabase service-role key in browser code.

## House-rule assumptions captured
- Press opportunity appears when a player is 2 holes down in an eligible match.
- Press requires explicit confirmation.
- Press starts on the next hole, not the trigger hole.
- Pressed matches may themselves be pressed (recursive press chain).
- Default bet size is one fixed amount across wagers.
- Game formats: Nassau, Skins, Quota, Mega Nassau, Hammer, and custom.

## Rules that still need confirmation before production
- Course handicap calculation must use course rating, slope, par, tee, and applicable format allowance; Handicap Index alone is not a course handicap.
- For Mega Nassau, define whether each segment (front/back/overall or custom 9/18/36+ hole match) has independent press state. The data model allows each segment to be an independent match.
- Hammer rules are implemented as a separate state machine in `lib/hammer.ts`: first throw only at match start; only the current holder may throw again; opponent accepts to double the current hole amount and take the Hammer, or declines and loses the current amount; accepted throws can repeat without a configured cap. The declined Hammer remains with the thrower, and that hole's Hammer wager is complete.
- Skins carryovers, Quota points, ties/pushes, conceded holes, max presses, and match completion/settlement policies should be configured and tested.
