import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{js,ts,jsx,tsx,mdx}", "./components/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { turf: "#1c6b48", ink: "#10231b", lime: "#c5f36a" } } },
  plugins: []
};
export default config;
