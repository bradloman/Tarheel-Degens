import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tarheel Degens",
  description: "The golf match, press, and betting ledger for your group."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
