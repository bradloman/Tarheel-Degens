'use client';

import { useMemo, useState } from "react";
import { CalendarDays, ChartNoAxesCombined, CircleDollarSign, Flag, History, Plus, Search, Trophy, Zap } from "lucide-react";
import { demoMatch } from "@/lib/demo-data";
import type { GameType, HoleScore } from "@/lib/types";
import { createPress } from "@/lib/press";

const games: GameType[] = ["Nassau", "Skins", "Quota", "Mega Nassau", "Hammer", "Custom"];

export default function Home() {
  const [tab, setTab] = useState<"live" | "history" | "stats">("live");
  const [match, setMatch] = useState(demoMatch);
  const [year, setYear] = useState("2026");
  const [filterGame, setFilterGame] = useState("All games");
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");
  const [pendingPress, setPendingPress] = useState<{wagerId: string; label: string; startsOn: number} | null>(null);

  const saveScore = (hole: number, player: 1 | 2, value: string) => {
    setMatch(old => {
      const scores = old.scores.map(s => s.hole === hole ? { ...s, [player === 1 ? "player1Gross" : "player2Gross"]: value === "" ? null : Number(value) } : s);
      return { ...old, scores };
    });
  };

  const scoreFor = (s: HoleScore, player: 1 | 2) => player === 1 ? s.player1Gross : s.player2Gross;
  const historyRows = useMemo(() => [
    { date: "2026-10-14", course: "Demo Club", game: "Nassau", result: "In progress", net: 0 },
    { date: "2026-08-22", course: "Demo Club", game: "Skins", result: "You won", net: 30 },
    { date: "2026-06-03", course: "Pine Ridge", game: "Quota", result: "Your buddy won", net: -20 },
    { date: "2025-11-16", course: "Demo Club", game: "Mega Nassau", result: "You won", net: 50 }
  ].filter(r => (year === "All years" || r.date.startsWith(year)) && (filterGame === "All games" || r.game === filterGame) && `${r.course} ${r.game} ${r.result}`.toLowerCase().includes(search.toLowerCase())), [year, filterGame, search]);

  const startPress = (wagerId: string) => {
    const parent = match.wagers.find(w => w.id === wagerId);
    if (!parent) return;
    const child = createPress(parent, `press-${Date.now()}`, match.currentHole);
    setMatch(old => ({ ...old, wagers: [...old.wagers, child] }));
    setNotice(`${child.label} added. Starts on hole ${child.pressStartHole}.`);
    setPendingPress(null);
  };

  return <main className="min-h-screen">
    <header className="bg-[#10231b] text-white">
      <div className="mx-auto max-w-6xl px-4 py-5 sm:px-6">
        <div className="flex items-center justify-between gap-3">
          <div><p className="text-xs font-bold tracking-[.28em] text-[#c5f36a]">THE CLUBHOUSE</p><h1 className="mt-1 text-2xl font-black tracking-tight sm:text-3xl">TARHEEL <span className="text-[#c5f36a]">DEGENS</span></h1></div>
          <div className="rounded-xl border border-white/15 bg-white/5 px-3 py-2 text-right"><p className="text-[10px] uppercase tracking-wider text-white/60">Season</p><p className="font-bold">2026</p></div>
        </div>
        <nav className="mt-5 flex gap-2 overflow-x-auto pb-1">
          {([{id:"live",label:"Live Match",icon:Flag},{id:"history",label:"History",icon:History},{id:"stats",label:"Stats",icon:ChartNoAxesCombined}] as const).map(item => <button key={item.id} onClick={() => setTab(item.id)} className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold ${tab === item.id ? "bg-[#c5f36a] text-[#10231b]" : "bg-white/10 text-white"}`}><item.icon size={16}/>{item.label}</button>)}
        </nav>
      </div>
    </header>

    <div className="mx-auto max-w-6xl space-y-5 px-4 py-5 sm:px-6 sm:py-8">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric label="YOUR INDEX" value="12.6" sub="Handicap Index" icon={<Flag size={18}/>} />
        <Metric label="FRIEND'S INDEX" value="15.3" sub="Handicap Index" icon={<Trophy size={18}/>} />
        <Metric label="SEASON NET" value="Demo" sub="Connect shared ledger" icon={<CircleDollarSign size={18}/>} />
        <Metric label="ACTIVE BETS" value={String(match.wagers.filter(w => w.status === "active").length)} sub="Across all game types" icon={<Zap size={18}/>} />
      </div>

      {notice && <div className="panel flex items-start justify-between gap-3 p-3 text-sm"><span>{notice}</span><button className="font-bold" onClick={() => setNotice("")}>Dismiss</button></div>}

      {tab === "live" && <>
        <section className="panel overflow-hidden">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#e1e8e2] p-4 sm:p-5">
            <div><div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-emerald-500"/><span className="text-xs font-bold uppercase tracking-widest text-[#1c6b48]">Live scorecard · demo data</span></div><h2 className="mt-1 text-xl font-extrabold">{match.course}</h2><p className="text-sm text-gray-500">{match.date} · {match.gameTypes.join(" / ")}</p></div>
            <div className="rounded-xl bg-[#eef4ef] px-4 py-3"><p className="text-xs text-gray-500">Fixed bet amount</p><p className="text-xl font-black">${match.fixedBetAmount} <span className="text-sm font-medium">per bet</span></p></div>
          </div>
          <div className="grid gap-4 p-4 sm:p-5 lg:grid-cols-[1.2fr_.8fr]">
            <div>
              <div className="overflow-x-auto rounded-xl border border-[#e1e8e2]">
                <table className="w-full min-w-[600px] text-center text-sm">
                  <thead className="bg-[#eef4ef]"><tr><th className="p-3 text-left">Hole</th>{match.scores.map(s => <th key={s.hole} className="p-2">{s.hole}</th>)}</tr></thead>
                  <tbody>
                    <tr className="border-t"><th className="p-3 text-left">Par</th>{match.scores.map(s => <td key={s.hole} className="p-2">{s.par}</td>)}</tr>
                    {match.players.map((p, pi) => <tr key={p.id} className="border-t"><th className="p-3 text-left"><span className="block font-bold">{p.name}</span><span className="text-xs font-normal text-gray-500">Index {p.handicapIndex}</span></th>{match.scores.map(s => <td key={s.hole} className="p-1"><input aria-label={`${p.name} gross score hole ${s.hole}`} className="w-10 rounded-md border border-[#d8e2d9] py-2 text-center" min="1" max="15" type="number" value={scoreFor(s, (pi + 1) as 1 | 2) ?? ""} onChange={e => saveScore(s.hole, (pi + 1) as 1 | 2, e.target.value)} /></td>)}</tr>)}
                  </tbody>
                </table>
              </div>
              <p className="mt-2 text-xs text-gray-500">Demo inputs update this browser only. Hole-by-hole handicap strokes require the course/tee rating, slope, par, and stroke index.</p>
            </div>
            <div className="space-y-3">
              <div className="rounded-xl bg-[#10231b] p-4 text-white"><p className="text-xs uppercase tracking-widest text-white/60">Match status</p><div className="mt-2 flex items-end justify-between"><div><p className="text-2xl font-black">1 UP</p><p className="text-sm text-white/70">You · illustrative</p></div><div className="text-right"><p className="text-xs text-white/60">CURRENT HOLE</p><p className="text-3xl font-black">{match.currentHole}</p></div></div></div>
              <div className="panel p-4"><div className="flex items-center justify-between"><h3 className="font-extrabold">Bet ledger</h3><span className="rounded-full bg-[#eef4ef] px-2 py-1 text-xs font-bold">{match.wagers.length} bets</span></div><div className="mt-3 space-y-2">{match.wagers.map(w => <div key={w.id} className="flex items-center justify-between gap-2 rounded-lg bg-[#f5f7f4] p-3"><div><p className="text-sm font-bold">{w.label}</p><p className="text-xs text-gray-500">{w.status}{w.pressParentId ? " · press" : ""}</p></div><span className="font-extrabold">${w.amount}</span></div>)}</div></div>
            </div>
          </div>
        </section>
        <section className="panel p-4 sm:p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-lg font-extrabold">Press control</h2><p className="text-sm text-gray-500">Press starts next hole and requires confirmation. Presses can be pressed again.</p></div><span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-900">Confirmation required</span></div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">{match.wagers.filter(w => w.status === "active").map(w => <div key={w.id} className="flex items-center justify-between gap-3 rounded-xl border border-[#e1e8e2] p-3"><div><p className="font-bold">{w.label}</p><p className="text-sm text-gray-500">${w.amount} · eligible match</p></div><button className="btn btn-secondary text-sm" onClick={() => setPendingPress({wagerId:w.id,label:w.label,startsOn:match.currentHole+1})}>Press bet</button></div>)}</div>
          <p className="mt-3 text-xs text-gray-500">Demo: press buttons are manually available for UI testing. Production logic must validate the two-down trigger for that specific match segment.</p>
        </section>
      </>}

      {tab === "history" && <section className="panel p-4 sm:p-5"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-xl font-extrabold">Match history</h2><p className="text-sm text-gray-500">Browse your golf and betting seasons.</p></div><CalendarDays className="text-[#1c6b48]"/></div>
        <div className="mt-4 grid gap-3 sm:grid-cols-3"><select className="field" value={year} onChange={e => setYear(e.target.value)}><option>All years</option><option>2026</option><option>2025</option><option>2024</option></select><select className="field" value={filterGame} onChange={e => setFilterGame(e.target.value)}><option>All games</option>{games.map(g => <option key={g}>{g}</option>)}</select><div className="relative"><Search className="absolute left-3 top-3 text-gray-400" size={17}/><input className="field pl-9" placeholder="Search courses, results..." value={search} onChange={e => setSearch(e.target.value)}/></div></div>
        <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[520px] text-left text-sm"><thead className="text-xs uppercase text-gray-500"><tr><th className="p-3">Date</th><th className="p-3">Course</th><th className="p-3">Game</th><th className="p-3">Result</th><th className="p-3 text-right">Net</th></tr></thead><tbody>{historyRows.map((r,i) => <tr key={i} className="border-t border-[#e1e8e2]"><td className="p-3">{r.date}</td><td className="p-3 font-bold">{r.course}</td><td className="p-3">{r.game}</td><td className="p-3">{r.result}</td><td className={`p-3 text-right font-extrabold ${r.net>0?"text-emerald-700":r.net<0?"text-rose-700":""}`}>{r.net>0?"+":""}${r.net}</td></tr>)}</tbody></table>{historyRows.length===0 && <p className="p-6 text-center text-sm text-gray-500">No matches match these filters.</p>}</div>
      </section>}

      {tab === "stats" && <section className="panel p-4 sm:p-5"><h2 className="text-xl font-extrabold">Season statistics</h2><p className="mt-1 text-sm text-gray-500">Illustrative placeholder stats until a shared ledger is connected.</p><div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3"><Stat title="Net winnings" value="$60" note="Sample history only"/><Stat title="Best game" value="Mega Nassau" note="Sample history only"/><Stat title="Rounds logged" value="4" note="Sample history only"/><Stat title="Presses activated" value="—" note="Connect the database"/><Stat title="Win rate" value="50%" note="Sample history only"/><Stat title="Biggest win" value="$50" note="Sample history only"/></div></section>}

      <footer className="flex flex-col justify-between gap-2 py-2 text-xs text-gray-500 sm:flex-row"><span>Tarheel Degens · Private golf group</span><span>Starter preview · demo values are not authoritative</span></footer>
    </div>

    {pendingPress && <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-3 sm:items-center"><div role="dialog" aria-modal="true" className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl"><div className="flex items-center gap-2 text-[#1c6b48]"><Zap size={20}/><p className="font-extrabold">Confirm press</p></div><h2 className="mt-3 text-xl font-black">{pendingPress.label}</h2><p className="mt-2 text-sm text-gray-600">This creates a separate press bet starting on hole {pendingPress.startsOn}. In production, this prompt appears only after the two-down trigger is validated for this specific match.</p><div className="mt-5 grid grid-cols-2 gap-3"><button className="btn btn-secondary" onClick={() => setPendingPress(null)}>Cancel</button><button className="btn btn-primary" onClick={() => startPress(pendingPress.wagerId)}>Confirm press</button></div></div></div>}
  </main>;
}

function Metric({label,value,sub,icon}:{label:string;value:string;sub:string;icon:React.ReactNode}) {
  return <div className="panel p-4"><div className="flex items-center justify-between text-[#1c6b48]"><span className="text-[10px] font-extrabold tracking-widest text-gray-500">{label}</span>{icon}</div><p className="mt-2 text-2xl font-black tracking-tight">{value}</p><p className="mt-1 text-xs text-gray-500">{sub}</p></div>;
}
function Stat({title,value,note}:{title:string;value:string;note:string}) {
  return <div className="rounded-xl bg-[#f5f7f4] p-4"><p className="text-sm text-gray-500">{title}</p><p className="mt-2 text-2xl font-black">{value}</p><p className="mt-1 text-xs text-gray-500">{note}</p></div>;
}
